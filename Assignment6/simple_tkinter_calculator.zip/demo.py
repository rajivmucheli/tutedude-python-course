"""Simple Tkinter Calculator Demo
All calculator logic and UI is defined here.
"""

import tkinter as tk


def run_calculator():
    root = tk.Tk()
    root.title("Simple Calculator")
    root.resizable(False, False)

    expression = tk.StringVar()

    # Display
    entry = tk.Entry(
        root,
        textvariable=expression,
        font=("Arial", 18),
        bd=10,
        relief=tk.RIDGE,
        justify="right"
    )
    entry.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

    def button_click(value):
        expression.set(expression.get() + str(value))

    def clear():
        expression.set("")

    def calculate():
        try:
            result = eval(expression.get())
            expression.set(str(result))
        except Exception:
            expression.set("Error")

    buttons = [
        ("7", 1, 0), ("8", 1, 1), ("9", 1, 2), ("/", 1, 3),
        ("4", 2, 0), ("5", 2, 1), ("6", 2, 2), ("*", 2, 3),
        ("1", 3, 0), ("2", 3, 1), ("3", 3, 2), ("-", 3, 3),
        ("0", 4, 0), (".", 4, 1), ("=", 4, 2), ("+", 4, 3),
    ]

    for (text, row, col) in buttons:
        if text == "=":
            tk.Button(
                root, text=text, width=10, height=2,
                command=calculate
            ).grid(row=row, column=col, padx=5, pady=5)
        else:
            tk.Button(
                root, text=text, width=10, height=2,
                command=lambda t=text: button_click(t)
            ).grid(row=row, column=col, padx=5, pady=5)

    tk.Button(
        root, text="C", width=42, height=2, command=clear
    ).grid(row=5, column=0, columnspan=4, padx=5, pady=5)

    root.mainloop()


if __name__ == "__main__":
    run_calculator()
