"""Main entry point"""

from demo import run_calculator

if __name__ == "__main__":
    run_calculator()
